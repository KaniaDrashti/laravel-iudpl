<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\loginController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/ins',function(){
    return view('ins');
});
Route::get('/disp',function(){
    return view('disp');
});
//home redirect
Route::post('/ins',[loginController::class,'getins']);
//login redirect
Route::get('/login',[loginController::class,'login']);
//chk login
Route::post('/ins',[loginController::class,'logindata']);
//insert
Route::post('/proc',[loginController::class,'getins']);
Route::get('/disp',[loginController::class,'disp']);
//edit
Route::get('/edit/{mid}', [loginController::class, 'edit'])->name('edit');
Route::post('/editdata', [loginController::class, 'editdata'])->name('editdata');
//delete
Route::get('/delete/{id}', [loginController::class, 'delete'])->name('delete');