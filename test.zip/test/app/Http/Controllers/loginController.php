<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class loginController extends Controller
{
    public function login()
    {
        return view('login');
    }
    public function logindata(Request $req)
    {
            $rec=DB::table('login_master')->where('uname',$req->txtuname)
                                         ->where('pass',$req->txtpass)->count();
                                       
                                          if($rec==1)
                                          {
                                              return redirect('ins');
                                          }
                                          else
                                          {
                                             return redirect('login');
                                          }
    }
    public function getins(Request $request)
    {
        DB::table('mdata')->insert(
            [
                'age'=>$request->txtage,
                'loan'=>$request->txtloan,
                'defaultt'=>$request->txtdefaultt,
                'distance'=>$request->txtdistance
               
            ]);
          return redirect('disp');
        
    }
    //display
    function disp(Request $req)
    {
    $data=DB::table('mdata')->get();
    return view('disp',compact('data'));
    }
    function edit($mid, Request $req)
    {
        $res=DB::table('mdata')->where('mid', $mid)->first();
        return view('edit',compact('res'));
    }
    function editdata(Request $req)
    {
        DB::table('mdata')->where('mid', $req->mid)
        ->update(['age'=>$req->age, 'loan'=>$req->loan, 'defaultt'=>$req->defaultt, 'distance'=>$req->distance]);
        return redirect('disp');
    }
    function delete($id){
        DB::table('mdata')->where('mid', $id)
                             ->delete();
        return redirect('disp');
    }
}
