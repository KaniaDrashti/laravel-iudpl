<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap.min.css')); ?>">
    <style>
        body {
            font-family: 'Nunito', sans-serif;
        }
    </style>
    <title>Add Product</title>
</head>
<body>
    <div class="container col-6">
        <h1 class="mt-2">Data edit</h1>
        <hr>

        <form action="<?php echo e(route('editdata')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="hidden" name="mid" value="<?php echo e($res->mid); ?>" class="form-control" placeholder="Enter mid">
            </div>
            <div class="form-group">
                <label for="age">age</label>
                <input type="text" name="age" value="<?php echo e($res->age); ?>" class="form-control" placeholder="Enter age">
            </div>
            <div class="form-group">
                <label for="loan">loan</label>
                <input type="text" name="loan" value="<?php echo e($res->loan); ?>" class="form-control" placeholder="Enter loan">
            </div>
            <div class="form-group">
                <label for="defaultt">Defaultt</label>
                <input type="text" name="defaultt" value="<?php echo e($res->defaultt); ?>" class="form-control" placeholder="defaultt">
            </div>
            <div class="form-group">
                <label for="distance">Distance</label>
                <input type="text" name="distance" value="<?php echo e($res->distance); ?>" class="form-control" placeholder="Enter distance">
            </div>
            <div class="form-group">
                <button class="btn btn-block btn-primary" type="submit">Edit Product</button>
            </div>
        </form>
    </div>
</body>
</html><?php /**PATH C:\Users\Drashti\test\resources\views/edit.blade.php ENDPATH**/ ?>